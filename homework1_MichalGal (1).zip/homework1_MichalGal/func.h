

#ifndef FUNC_H_
#define FUNC_H_

void printMat(const int* mat, int rows,int cols);
int randomNumber(int minRange, int maxRange);



#endif /* FUNC_H_ */
